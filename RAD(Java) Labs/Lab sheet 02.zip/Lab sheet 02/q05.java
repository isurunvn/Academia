public class q05 {
    public static void main(String[] args) {
        int i =10;
        while (i>0){
            System.out.println(i);
            i--;
        }
    }
}
