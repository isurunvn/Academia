public class q04 {
    public static void main(String[] args) {
        double a = 20.5;
        double b = 30.5;

        if (a>b && a<100){
            System.out.println("Great");
        } else if (a>b || a<100) {
            System.out.println("Good");
        }

        if (a!=20){
            System.out.println("a is not eqaul to 20");
        } else {
            System.out.println("a is equal to 20");
        }

    }
}
