public class q02 {
    public static void main(String[] args) {
        double a = 9;

        if (a>=10){
            System.out.println("Good");
        }else {
            System.out.println("Bad");
        }
    }
}
