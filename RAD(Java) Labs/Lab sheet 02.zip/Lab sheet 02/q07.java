public class q07 {
    public static void main(String[] args) {
        for (int i=15; i>0; i--){
            System.out.println(i);
        }
    }
}
