public class q01 {
    public static void main(String[] args) {
        int a=20;
        int b=10;
        int c=3;

        int add = a+b;
        int sub = a-b;
        int mul = a*b;
        int div = 20/10;
        int rem = 20%3;


        System.out.println("Addition:"+ add);
        System.out.println("Substraction:"+ sub);
        System.out.println("Multiplication:"+ mul);
        System.out.println("Division:"+ div);
        System.out.println("Remainder:"+ rem);
    }
}
