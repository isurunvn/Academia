#include "libraryManage.h"
#include <stdio.h>
#include <string.h>

int main(){
    struct TreeNode* root = NULL;
    int n, isbn;

    printf("How many books you have to enter to the system: ");
    scanf("%d",&n);

    for(int i=0; i<n; i++){
        printf("Enter the ISBN number of the book: ");
        scanf("%d",&isbn);

        root = insertNode(root, isbn);
    }

    inOrderTraversal(root);
    printf("\n");    printf("\n");
    printf("\n");

    preOrderTraversal(root); 
    printf("\n");    printf("\n");
    printf("\n");

    postOrderTraversal(root); 

    return 0;
}